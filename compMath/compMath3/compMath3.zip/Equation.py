class Equation:
    def __init__(self, f, discontinuity_points, string_form):
        self.f = f
        self.discontinuity_points = discontinuity_points
        self.string_form = string_form
