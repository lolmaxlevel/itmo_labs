class Equation:
    def __init__(self, equation, equation_g, string):
        self.equation = equation
        self.equation_g = equation_g
        self.string = string
